<div class="row-fluid pricing-table pricing-three-column" style="margin-top: 10px;display:block;width:100%;overflow:hidden">

	<div class="purchase_btn_div" style="margin-top:20px;text-align: center;">
	  <a  style= "margin-right:10px;" href="http://demo.weblizar.com/ultimate-responsive-image-slider-pro/" target="_new" class="btn btn-primary btn-lg">View Demo</a>
	  <a style= "margin-right:10px;" href="https://weblizar.com/plugins/ultimate-responsive-image-slider-pro/" target="_new" class="btn btn-success btn-lg">Try Before Buy</a>
	  <a href="https://weblizar.com/plugins/ultimate-responsive-image-slider-pro/" target="_new" class="btn btn-danger btn-lg">Upgrade To Pro</a>
		
	</div>
	
	<div class="plan-name" style="margin-top:40px;text-align: center;">
        <h2 style="font-weight: bold;font-size: 36px;padding-top: 30px;padding-bottom: 10px;">Ultimate Responsive Slider Pro Screen shot</h2>
		<h6 style="font-size: 22px;padding-top: 10px;padding-bottom: 10px;">A Perfect Responsive Image Slider plugin for WordPress. Contain 5 types of slider layout. Tested on all browser like Chrome, Mozilla, Safari, IE etc...</h6>
    </div>
	<div class="plan-name"><!-- SLIDER-INTRO-->
				<!--===============================================================-->
			<div class="col-md-12 col-sm-12">
				<a href="https://weblizar.com/plugins/ultimate-responsive-image-slider-pro/" target="_new"><h2 style="font-weight: bold;font-size: 26px;padding-top: 20px;padding-bottom: 20px; text-align:center">Pro Version Demos</h2>
				<img class="img-responsive" style="width:100%;border: 1px solid #e3e3e3;background: #f7f7f7;padding:10px" src="<?php echo  WRIS_PLUGIN_URL.'img/detail-product.jpg'; ?>" alt=""/>
				</a>
			</div>
			
		</div>
					
</div>
<div class="plan-name" style="padding-top:40px; text-align: center;display:block;width:100%;overflow:hidden">
 
	<div class="purchase_btn_div" style="margin-top:20px;text-align: center;">
	  <a  style= "margin-right:10px;" href="http://demo.weblizar.com/ultimate-responsive-image-slider-pro/" target="_new" class="btn btn-primary btn-lg">View Demo</a>
	  <a style= "margin-right:10px;" href="https://weblizar.com/plugins/ultimate-responsive-image-slider-pro/" target="_new" class="btn btn-success btn-lg">Try Before Buy</a>
	  <a href="https://weblizar.com/plugins/ultimate-responsive-image-slider-pro/" target="_new" class="btn btn-danger btn-lg">Upgrade To Pro</a>
	
	</div>
</div>
<div class="plan-name" style="padding-top:40px; text-align: center;display:block;width:100%;overflow:hidden">
        <h2 style="font-weight: bold;font-size: 36px;padding-top: 10px;padding-bottom: 10px;">Ultimate Responsive Image Slider Pro And Free Comparison Table</h2>
</div>
<div class="row-fluid pricing-table pricing-three-column" style="margin-top: 10px;">
	<div class="col-md-4">
		<div class=" plan ap">
			<div class="plan-name">
				<h2>Ultimate Responsive </h2>
				<span>Image Slider Pro Features</span>
			</div>
			<ul>
				<li class="plan-feature">Responsiveness</li>
				<li class="plan-feature">Slider Layout</li>
				<li class="plan-feature">Touch Slider</li>
				<li class="plan-feature">Full Screen Slideshow</li>
				<li class="plan-feature">Thumbnail Slider</li>
				<li class="plan-feature">Color Options</li>
				<li class="plan-feature">Light Box</li>
				<li class="plan-feature">All Gallery Shortcode</li>
				<li class="plan-feature">Drag and Drop image Position</li>
				<li class="plan-feature">Multiple Image uploader</li>
				<li class="plan-feature">Shortcode Button on post or page</li>
				<li class="plan-feature">Unique settings for each gallery</li>
				<li class="plan-feature">Carousel Slider</li>
				<li class="plan-feature">External Link</li>
				<li class="plan-feature">Auto Play/Pause</li>
			 
			</ul>
		</div>
	</div>
	<div class="col-md-4">
		<div class=" plan bp">
			<div class="plan-name">
				<h2>Free</h2>
				<span>$0</span>
			</div>
			<ul>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature">1</li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-times fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature">1</li>
				<li class="plan-feature"><i class="fa fa-times fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-times fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-times fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-times fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-times fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				
				<li class="plan-feature">
					<a target="_new" href="https://wordpress.org/plugins/ultimate-responsive-image-slider/" class="button button-primary button-hero" ><i class="fa fa-download"></i> Download</a>
				</li>
			</ul>
		</div>
	</div>
	
	<div class="col-md-4">
		<div class=" plan cp">
			<div class="plan-name">
				<h2>Pro</h2>
				<span>$21</span>
			</div>
			<ul>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature">5</li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature">Unlimited</li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				<li class="plan-feature"><i class="fa fa-check fa-1x"></i></li>
				
				<li class="plan-feature">
					<a class="btn btn-primary btn-lg" target="_new" href="http://demo.weblizar.com/ultimate-responsive-image-slider-pro/" target="_new" ><i class="fa fa-check-circle"></i> Demo</a>
					<a class="btn btn-danger btn-lg" href="https://weblizar.com/plugins/ultimate-responsive-image-slider-pro/"  ><i class="fa fa-shopping-cart"></i> Buy</a>
				</li>
			</ul>
		</div>
	</div>	
</div>
<style>
    .pricing-table .plan ul li.plan-feature {
        padding: 8px !important;
    }
    .ap .plan-name {
        background-color: #1E8CBE !important;
    }
    .bp .plan-name {
        background-color: #1E8CBE !important;
    }
    .cp .plan-name {
        background-color: #1E8CBE !important;
    }
    li {
        font-size: larger !important;
    }

    .row-fluid .span4 {
        width: 30.624% !important;
    }
	
	ul li img {
		
	}
</style>
