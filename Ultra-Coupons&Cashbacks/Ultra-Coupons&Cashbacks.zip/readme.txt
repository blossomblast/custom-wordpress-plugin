Ultra Coupons & Cashbacks  - WordPress Plugin
=============================

### WordPress Plugin - Ultra Coupons & Cashbacks  is a Coupon Mirror! ###

This is a mirror of Ultra Coupons & Cashbacks Coupon's WordPress Plugin which was removed recently for unknown reasons and was available at [http://wordpress.org/plugins/ultra-coupon-cashbacks/](http://wordpress.org/plugins/drp-coupon/)

**Note:** I'm in no way, shape or form affiliated with the plugin or the developers of this plugin. Refer the plugin's license for more information about the permissions/rights or contact the plugin's developer on their official site - directresponsepublishing.com

---

**Contributors:** Direct Response Publishing

**Tags:** Ultra Coupons & Cashbacks Coupon, coupon, coupons, affiliate, links

**Requires at least:** `3.3.1`
**Tested up to:** `4.9.6`
**Stable tag:** `2.1`

Ultra Coupons & Cashbacks Coupon is a Wordpress Coupon Plugin which Allows You To Add Coupons that Expire or Don't Expire To Your Posts and Pages.

Description
-----------

Ultra Coupons & Cashbacks Coupon is  a Wordpress Coupon Plugin which Allows You To Add Coupons that Expire To Your Posts and Pages. Add a regular link or an affiliate link from which the coupon will go to when clicked. A person cannot copy the code unless they click on the link. Once clicked it will copy the coupon code to the clipboard ready for easy pasting.

You can also set future dates for coupons to appear. So if a coupon starts in a week or 24hrs you can set the date, insert into post or page and the coupon will only appear when that start date arrives.

You can also have coupons with no expiry date so they are always viewable

Your url is masked, go ahead mouse over it and you won't see your affiliate link.

Installation
------------

1. Upload Ultra Coupons & CashbacksCoupon directory to the `/wp-content/plugins/` directory or install  from wordpress plugin respository.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the Ultra Coupons & Cashbacks Coupon Options on left to make create and manage coupons.

Frequently Asked Questions
--------------------------

**How to do you display it after you create a coupon?**

 To have it show in a page or post.  You have **3 options**

1. Clicking a button in your post or page . it will show all the details about coupon among this. aearch/filter then find outr coupon then insert into post.
2.if you want to exclude some fields means thats also possible.





**What is the Custom Expiry message field?**

- Some people wanted to not have the coupon disappear and instead have a message appear. This lets you do that. If you insert a message and save, when the coupon date expires the coupon will still be seen and you will also see your custom message. If you don't fill it then your coupon will disappear upon expiry like before.

**Is there a way to have coupons always seen, so that they never expire?**

- Yes, leave start date and expiry date blank, and leave the expiry message field blank and check the box for excluding expiry date when you insert

**Why don’t you hide the coupon code?**

- Simple, now days if you don’t show the coupon most people think you aren’t going to give a coupon and you just want them to click through on your affiliate link. So this bullcrap about that by hiding it you are going to get people to click through to get the coupon is crap, as people want you to be transparent. Look at any of the top coupon places online and you will see them displaying the coupon. We make sure people can’t copy it which is enough. There are many many so called coupon sites online that are NOT offering coupons they say click here but they are just using an affiliate link, this makes damn sure you are being upfront with your visitors. 


**Is this plugin free?**

- Yes. Which means don't expect a lot unless your willing to throw cash my way ;)

**Does the link require http:// or can i just put www\.**

- You can put either one it works with both

**How can I see what it looks like before I activate it?**

- View the screenshots

Screenshots
-----------

1. Plugin admin panel `screenshot-1.jpg`
2. add coupon `screenshot-2.jpg`
3. category crreation  `category-create.jpg`
4. sub category creation 'subcategory.jpg'
5. insert into post/page 'insert_coupon.jpg'
6. output/front view of specified shortcode 'output.jpg'




Changelog
---------

**1.0**  

* This is my first wordpress coupon
* Using this can add vendors/categories and coupon.
* using shortcoe can insert anywhere on post/page.




***pro version***

*  After creating your coupon you go to post or page and click button and select coupon to insert
* hide coupon
* more than one template for coupon
* expired time countdown.

