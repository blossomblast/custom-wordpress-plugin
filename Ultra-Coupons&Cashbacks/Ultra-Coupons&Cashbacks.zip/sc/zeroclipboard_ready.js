jQuery(document).ready(function(){
	ZeroClipboard.setMoviePath(ZCData.swfPath);
});
